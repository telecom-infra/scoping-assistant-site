window.addEventListener('message', (event) => {
  if (event.source !== window) return;
  const msg = event.data;
  if (!msg || msg.source !== 'ATCO_SCOPING_ASSISTANT' || msg.type !== 'ATCO_ANVIL_TRANSFER_READY') return;
  chrome.runtime.sendMessage({type:'SCOPING_TRANSFER_READY',payload:msg.payload}).catch(()=>{});
});
