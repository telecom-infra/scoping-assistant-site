function normText(v){
  return String(v ?? '').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim().toLowerCase().replace(/:$/,'');
}
function visible(el){
  if(!el) return false;
  const r=el.getBoundingClientRect();
  return r.width>0 && r.height>0;
}
function labelForControl(el){
  return el?.closest('.flow-panel-gutter')?.querySelector('.label-text')?.textContent?.trim() || '';
}
function controlForLabel(target, preferred){
  const wanted=normText(target);
  const matches=[];
  for(const gutter of document.querySelectorAll('.flow-panel-gutter')){
    const label=gutter.querySelector('.label-text');
    if(!label || normText(label.textContent)!==wanted) continue;
    const controls=[...gutter.querySelectorAll('input, select, textarea')].filter(visible);
    if(preferred){
      const filtered=controls.filter(c => {
        if(preferred==='select') return c.tagName==='SELECT';
        if(preferred==='textarea') return c.tagName==='TEXTAREA';
        if(preferred==='input') return c.tagName==='INPUT';
        return true;
      });
      matches.push(...filtered);
    } else matches.push(...controls);
  }
  return matches;
}
function getControl(target, preferred){
  return controlForLabel(target, preferred)[0] || null;
}
function formReady(){
  return !!getControl('Project Number','input');
}
function nativeSet(el, value){
  el.focus();
  const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(proto,'value')?.set;
  if(setter) setter.call(el, value); else el.value=value;
  el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:String(value??'')}));
  el.dispatchEvent(new Event('change',{bubbles:true}));
  el.blur();
}
function normalizeOptionText(v){
  return String(v??'').trim().replace(/\s+/g,' ').replace(/\s*-\s*/g,'-').toLowerCase();
}
function selectByText(select, wanted){
  const target=normalizeOptionText(wanted);
  const options=[...select.options];
  let opt=options.find(o=>normalizeOptionText(o.text)===target);
  if(!opt){
    const code=(String(wanted).match(/\b\d{5}\b/)||[])[0];
    const clli=(String(wanted).match(/\b[A-Za-z]{4}\b/)||[])[0]?.toLowerCase();
    if(code) opt=options.find(o=>String(o.text).replace(/\s+/g,' ').includes(code));
    if(!opt && clli) opt=options.find(o=>String(o.text).toLowerCase().includes(clli));
  }
  if(!opt) return {ok:false,error:`Option not found: ${wanted}`};
  select.focus();
  select.value=opt.value;
  select.dispatchEvent(new Event('input',{bubbles:true}));
  select.dispatchEvent(new Event('change',{bubbles:true}));
  select.blur();
  return {ok:true,selected:opt.text};
}
function formatDate(v){
  if(!v) return '';
  const m=String(v).match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if(m) return `${Number(m[2])}/${Number(m[3])}/${m[1]}`;
  return String(v);
}
function setInput(label,value){
  const c=getControl(label,'input');
  if(!c) return {ok:false,error:`Field not found: ${label}`};
  nativeSet(c,String(value??''));
  return {ok:true,value:c.value};
}
function setSelect(label,value){
  const c=getControl(label,'select');
  if(!c) return {ok:false,error:`Dropdown not found: ${label}`};
  return selectByText(c,value);
}
function setTextarea(label,value){
  const c=getControl(label,'textarea');
  if(!c) return {ok:false,error:`Field not found: ${label}`};
  nativeSet(c,String(value??''));
  return {ok:true,value:c.value};
}

async function transfer(fields){
  if(!formReady()) return {ok:false,count:0,results:[],error:'The Anvil Create Project form was not detected.'};
  const norm = v => String(v ?? '').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim().toLowerCase().replace(/:$/,'').replace(/ ?([\/\-(]) ?/g,'$1');
  const readValue = (c, type) => { try { return type==='select' ? String(c.options?.[c.selectedIndex]?.text ?? '') : String(c.value ?? ''); } catch { return ''; } };
  const MAPPINGS=[
    { key:'projectNumber',      label:'Project Number',            type:'input',    fmt:v=>v },
    { key:'altProjectNumber',   label:'Alternate Project Number',  type:'input',    fmt:v=>v },
    { key:'projectAddress',     label:'Project Address/Description',type:'input',   fmt:v=>v },
    { key:'dateReceived',       label:'Date Received',              type:'input',    fmt:v=>formatDate(v) },
    { key:'customer',           label:'Customer',                   type:'select',   fmt:v=>v },
    { key:'customerContact',    label:'Customer Contact',           type:'input',    fmt:v=>v },
    { key:'atcoContact',        label:'ATCO Contact',               type:'input',    fmt:v=>v },
    { key:'scope',              label:'Work Type',                  type:'select',   fmt:v=>v },
    { key:'exchange',           label:'Exchange',                   type:'select',   fmt:v=>v },
    { key:'scoperNotes',        label:'Notes',                      type:'textarea', fmt:v=>v }
  ];
  // Deterministic resolver matching the service worker's injected fill. Anvil nests
  // field gutters, so an ancestor gutter can carry the same label as its leaf: walk
  // to the SMALLEST matching container and break same-size ties by pinned control type.
  const resolveField = (wantedLabel, pref) => {
    const wanted = norm(wantedLabel);
    const prefTag = pref === 'select' ? 'SELECT' : pref === 'textarea' ? 'TEXTAREA' : 'INPUT';
    const inventory = () => [...document.querySelectorAll('.flow-panel-gutter')].slice(0, 40).map(g => {
      const lab = String(g.querySelector('.label-text')?.textContent || '').trim();
      const tags = [...g.querySelectorAll('input, select, textarea')].map(c => c.tagName.toLowerCase());
      return lab ? `${lab}(${tags.join(',')})` : null;
    }).filter(Boolean).join(' | ');
    const controlCount = g => g.querySelectorAll('input, select, textarea').length;
    let matches = [], bestScore = 0;
    for (const gutter of document.querySelectorAll('.flow-panel-gutter')) {
      const labelEl = gutter.querySelector('.label-text');
      if (!labelEl) continue;
      const text = norm(labelEl.textContent);
      const eq = text === wanted;
      const annotated = text.startsWith(wanted) && (text.length === wanted.length || /^[ (]/.test(text.slice(wanted.length)));
      const score = eq ? 3 : (annotated ? 2 : 0);
      if (score === 0) continue;
      if (score > bestScore) { bestScore = score; matches = [gutter]; }
      else if (score === bestScore) matches.push(gutter);
    }
    if (!matches.length) return { ok:false, reason:`Field not found by label: "${wantedLabel}". Gutters seen: ${inventory()}` };
    let candidates = matches.filter(g => controlCount(g) === Math.min(...matches.map(controlCount)));
    const typed = candidates.filter(g => [...g.querySelectorAll('input, select, textarea')].some(c => c.tagName === prefTag));
    if (typed.length === 1) candidates = typed;
    if (candidates.length > 1) return { ok:false, reason:`Ambiguous: multiple containers match "${wantedLabel}"` };
    const best = candidates[0];
    const labelText = String(best.querySelector('.label-text')?.textContent || '').trim();
    const all = [...best.querySelectorAll('input, select, textarea')];
    let controls = all.filter(c => c.tagName === prefTag);
    if (!controls.length) controls = all;
    if (!controls.length) return { ok:false, reason:`No form control in container "${labelText}"` };
    const onscreen = controls.filter(visible);
    let control = null, vis = false;
    if (onscreen.length === 1) { control = onscreen[0]; vis = true; }
    else if (controls.length === 1) { control = controls[0]; vis = false; }
    else return { ok:false, reason:`Multiple controls in container "${labelText}"` };
    return { ok:true, control, controlType:control.tagName, mode:bestScore===3?'exact':'includes', visible:vis, labelText };
  };
  const writeValue = async (c, type, value) => {
    if (type === 'select') return setSelect(c, value) ? { ok:true, written:c.options[c.selectedIndex]?.text, expectation:c.options[c.selectedIndex]?.text }
      : { ok:false, reason:`Option not found: "${value}"` };
    nativeSet(c, String(value ?? ''));
    return { ok:true, written:String(value ?? ''), expectation:String(value ?? '') };
  };
  const verify = (c, type, expectation) => {
    try { return norm(readValue(c, type)) === norm(String(expectation ?? '')); }
    catch { return false; }
  };
  const results=[];
  let transferred=0, failed=0, skipped=0;
  for(const { key,label,type,fmt } of MAPPINGS){
    if(!(key in fields)) continue;
    const base={ key, label };
    const raw=fields[key];
    if(String(raw ?? '').trim()===''){
      results.push({ ...base, status:'skipped', ok:false, skipped:true, error:'Blank value' });
      skipped++;
      continue;
    }
    const value=fmt(raw);
    const resolved=resolveField(label, type);
    if(!resolved.ok){
      results.push({ ...base, status:'unmatched', ok:false, error:resolved.reason });
      failed++;
      continue;
    }
    let written;
    try{ written = await writeValue(resolved.control, type, value); }
    catch(err){ written = { ok:false, reason:err?.message || String(err) }; }
    if(!written.ok){
      results.push({ ...base, status:'write_failed', ok:false, error:written.reason, matched:resolved.mode, controlType:resolved.controlType });
      failed++;
      continue;
    }
    if(!verify(resolved.control, type, written.expectation)){
      results.push({ ...base, status:'verify_failed', ok:false, error:'Write did not stick (readback mismatch)', matched:resolved.mode, controlType:resolved.controlType, written:written.written, readback:readValue(resolved.control, type) });
      failed++;
      continue;
    }
    results.push({ ...base, status:'ok', ok:true, matched:resolved.mode, controlType:resolved.controlType, visibility:resolved.visible?'ok':'fallback', value:written.written, verified:true });
    transferred++;
    await new Promise(resolve=>setTimeout(resolve,70));
  }
  return {
    ok: failed===0,
    count: transferred,
    failed,
    skipped,
    results,
    warning: skipped ? `${skipped} selected field${skipped===1?' was':'s were'} blank and skipped.` : ''
  };
}

function status(){
  const ready=formReady();
  chrome.runtime.sendMessage({
    type:'ANVIL_STATUS',
    ready,
    detail:ready?'Anvil Create Project page detected.':'Open Anvil → Create Project.'
  }).catch(()=>{});
}
chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
  if(msg?.type==='ATCO_TRANSFER_TO_ANVIL'){
    transfer(msg.fields||{}).then(sendResponse);
    return true;
  }
});
status();
const observer=new MutationObserver(()=>status());
observer.observe(document.documentElement,{subtree:true,childList:true});
setInterval(status,2000);
