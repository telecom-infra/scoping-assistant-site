# ATCO Anvil Transfer v0.1.9 — Chrome beta

Small companion browser extension for transferring finalized Scoping Assistant project values into the ATCO Anvil Create Project form.

## ATCO Portal
https://atcotrafficcontrol.anvil.app/

## Live Scoping Assistant
https://telecom-infra.github.io/scoping-assistant-site/

## Workflow
1. Build/review the project in the Scoping Assistant.
2. Use **Create New Project in Anvil** in the Scoping Assistant or refresh from the open Scoping Assistant tab.
3. Open the ATCO Anvil Transfer side panel.
4. Confirm the project is detected.
5. Choose fields to transfer.
6. Click **Transfer Selected Fields**.
7. Review the populated Anvil form, upload files, complete anything missing, and create the project manually.

The extension does not click Anvil's Create Project button.

## v0.1.9 changes
- Adds GitHub Pages access for the live Scoping Assistant at `telecom-infra.github.io/scoping-assistant-site`.
- Enables the Scoping Assistant message bridge on the live site.
- Refresh from Scoping Assistant can read the live GitHub Pages tab.
- Live Scoping Assistant URL is prioritized when discovering the project tab.
- Fixes the full-width Open ATCO Portal button layout in the side panel.

## Available transfer fields
Project Number, Alternate Project Number, Project Address / Description, Date Received, Customer, Work Type, Exchange, and Notes.

Not mapped yet: Assigned To, CLLI Code, Engineer, OSP Engineering Manager, Engineering Coordinator, and Confirmed Permit Jurisdiction.

Edge remains the primary tested browser for this beta. Chrome uses the same transfer logic and is packaged separately for validation.
