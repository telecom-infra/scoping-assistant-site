const ANVIL_URL = 'https://atcotrafficcontrol.anvil.app/';
const FIELD_KEYS = [
  'projectNumber','altProjectNumber','projectAddress','dateReceived',
  'customer','scope','exchange','scoperNotes'
];
const defaultSelections = Object.fromEntries(FIELD_KEYS.map(k => [k, true]));
const PROBE_TIMEOUT_MS = 8000;

chrome.runtime.onInstalled.addListener(async () => {
  const current = await chrome.storage.local.get(['selections']);
  if (!current.selections) await chrome.storage.local.set({selections: defaultSelections});
  if (!current.scopingStatus) await chrome.storage.local.set({scopingStatus:{ready:false,detail:'Looking for an open Scoping Assistant project.'}});
});

async function getState(){
  const s = await chrome.storage.local.get(['pendingTransfer','selections','anvilStatus','lastTransfer','scopingStatus','scopingDiagnostic']);
  return {
    pendingTransfer: s.pendingTransfer || null,
    selections: s.selections || defaultSelections,
    anvil: s.anvilStatus || {ready:false,detail:'Open Anvil → Create Project.'},
    lastTransfer: s.lastTransfer || null,
    scoping: s.scopingStatus || {ready:false,detail:'Looking for an open Scoping Assistant project.'},
    scopingDiagnostic: s.scopingDiagnostic || null
  };
}

async function notifyPanel(){
  try { await chrome.runtime.sendMessage({type:'STATE_UPDATED'}); } catch (_) {}
}

function withTimeout(promise, ms, label){
  return Promise.race([
    Promise.resolve(promise),
    new Promise((_, reject) => setTimeout(() => reject(new Error(`${label} timed out after ${ms}ms`)), ms))
  ]);
}

function isScopingUrl(rawUrl){
  try{
    const u=new URL(String(rawUrl || ''));
    return u.protocol === 'https:' &&
      u.hostname === 'telecom-infra.github.io' &&
      (u.pathname === '/scoping-assistant-site' || u.pathname.startsWith('/scoping-assistant-site/'));
  }catch(_){
    return false;
  }
}

function isLocalOrFileUrl(rawUrl){
  try{
    const u=new URL(String(rawUrl || ''));
    if(u.protocol === 'file:') return true;
    return ['http:','https:'].includes(u.protocol) && (u.hostname === 'localhost' || u.hostname === '127.0.0.1');
  }catch(_){
    return false;
  }
}

async function getScopingCandidates(){
  const tabs = await chrome.tabs.query({});
  const active = tabs.find(t => t.active) || null;
  const ordered = [
    ...(active ? [active] : []),
    ...tabs.filter(t => t.id !== active?.id)
  ];
  const candidates=[];
  const rejected=[];
  for(const t of ordered){
    const title=String(t.title || '');
    const titleLower=title.toLowerCase();
    const url=String(t.url || '');
    const githubUrl=isScopingUrl(url);
    const localOrFile=isLocalOrFileUrl(url);
    if(titleLower.includes('atco scoping assistant') || githubUrl){
      candidates.push(t);
    }else if(localOrFile){
      rejected.push({
        id:t.id, windowId:t.windowId ?? null, active:!!t.active,
        title, url,
        reason:'file:// / localhost URL without the "ATCO Scoping Assistant" title was treated as non-matching.'
      });
    }
  }
  return {candidates, rejected};
}

const probePresence=()=>{
  let navType='unknown';
  try{ navType=performance.getEntriesByType('navigation')?.[0]?.type || 'unknown'; }catch(_){}
  return {
    url:location.href,
    title:document.title,
    readyState:document.readyState,
    hasProject:!!document.getElementById('project'),
    projectValue:document.getElementById('project')?.value ?? null,
    projectAddressValue:document.getElementById('address')?.value ?? null,
    transferFieldCount:document.querySelectorAll('[data-transfer-field]').length,
    getTransferPayloadAvailable:typeof window.getTransferPayload === 'function',
    navigationType:navType
  };
};

async function probeCandidate(tabId, world, label){
  try{
    const opts={target:{tabId}};
    if(world==='MAIN') opts.world='MAIN';
    const r=await withTimeout(chrome.scripting.executeScript(Object.assign({func:probePresence},opts)), PROBE_TIMEOUT_MS, label);
    return {ok:true,result:r?.[0]?.result ?? null};
  }catch(err){
    return {ok:false,error:err?.message || String(err)};
  }
}

async function selectConfirmedScopingTab(){
  const startedAt=new Date().toISOString();
  const {candidates, rejected}=await getScopingCandidates();
  const inspected=[];
  let selected=null;
  for(const t of candidates){
    const res=await probeCandidate(t.id, 'ISOLATED', 'ISOLATED presence probe');
    inspected.push({
      id:t.id, windowId:t.windowId ?? null, index:t.index ?? null, active:!!t.active,
      title:String(t.title || ''), url:String(t.url || ''),
      probe:res
    });
    if(!selected && res.ok && res.result?.hasProject && (res.result?.transferFieldCount || 0) > 0){
      selected={
        id:t.id, windowId:t.windowId ?? null, index:t.index ?? null, active:!!t.active,
        title:String(t.title || ''), url:String(t.url || ''),
        presence:res.result,
        reason:'Presence confirmed (has #project element and transfer fields).'
      };
    }
  }
  if(!selected){
    const failing=inspected.map(t => ({
      id:t.id, url:t.url, reason: t.probe.ok
        ? `app presence not found (hasProject=${!!t.probe.result?.hasProject}, transferFieldCount=${t.probe.result?.transferFieldCount ?? 0})`
        : `probe failed: ${t.probe.error}`
    }));
    rejected.push(...failing);
  }
  return {startedAt, inspected, rejected, selected};
}

async function readWithTimeout(tabId, world='MAIN'){
  try{
    const r=await withTimeout(
      chrome.scripting.executeScript({target:{tabId},world,func:readScopingProject}),
      PROBE_TIMEOUT_MS, `${world} read`
    );
    return {ok:true,result:r?.[0]?.result ?? null};
  }catch(err){
    return {ok:false,error:err?.message || String(err)};
  }
}

async function runRefreshDiagnostics(){
  const detection=await selectConfirmedScopingTab();
  const out={...detection, isolatedRead:null, mainProbe:null, mainRead:null};
  const sel=detection.selected;
  if(!sel){
    out.error='No Scoping Assistant tab with confirmed app presence.';
    out.finishedAt=new Date().toISOString();
    return out;
  }
  out.isolatedRead=await readWithTimeout(sel.id, 'ISOLATED');
  out.mainProbe=await probeCandidate(sel.id, 'MAIN', 'MAIN probe');
  out.mainRead=await readWithTimeout(sel.id, 'MAIN');
  out.finishedAt=new Date().toISOString();
  return out;
}

function readScopingProject(){
  const clean=v => String(v ?? '').trim();
  const normalizedAddress = () => {
    const v=document.getElementById('address')?.value || '';
    return String(v).trim().replace(/[\n\r\t]+/g,' ').replace(/\s+/g,' ').replace(/\s*,\s*/g,', ').replace(/,+/g,',').replace(/^,|,$/g,'');
  };
  const navEntry = (() => {
    try { return performance.getEntriesByType('navigation')?.[0] || null; }
    catch (_) { return null; }
  })();
  const diagnostic={
    readSource:'unknown',
    getTransferPayloadAvailable: typeof window.getTransferPayload === 'function',
    navigationType: navEntry?.type || 'unknown',
    navigationStart: navEntry?.startTime ?? null,
    fieldKeys:[],
    appReadError:null
  };

  try{
    if(typeof window.getTransferPayload === 'function'){
      const payload=window.getTransferPayload();
      diagnostic.readSource='app';
      diagnostic.fieldKeys=Object.keys(payload?.fields || {});
      return {payload,diagnostic};
    }
  }catch(err){
    diagnostic.appReadError=err?.message || String(err);
  }

  const fields={
    projectNumber: clean(document.getElementById('project')?.value),
    altProjectNumber: clean(document.getElementById('altProjectNumber')?.value),
    projectAddress: normalizedAddress(),
    dateReceived: clean(document.getElementById('received')?.value),
    customer: clean(document.getElementById('client')?.value || 'Ziply'),
    scope: clean(document.getElementById('scope')?.value),
    exchange: clean(document.getElementById('exchange')?.value),
    clli: clean(document.getElementById('clli')?.value),
    engineer: clean(document.getElementById('engineer')?.value),
    exchangeManager: clean(document.getElementById('exchangeManager')?.value),
    coordinator: clean(document.getElementById('coordinator')?.value),
    selectedJurisdiction: clean(document.getElementById('selectedJurisdiction')?.value),
    assignedCoordinator: clean(document.getElementById('assignedCoordinator')?.value),
    scoperNotes: clean(document.getElementById('scoperNotes')?.value)
  };
  const checkboxes=[...document.querySelectorAll('[data-transfer-field]')];
  const selected = checkboxes.length ? Object.fromEntries(checkboxes.map(cb=>[cb.dataset.transferField, !!cb.checked])) : {};
  const out={};
  for(const [k,v] of Object.entries(fields)) if(!checkboxes.length || selected[k] !== false) out[k]=v;
  const payload={schema:'ATCO-Anvil-Transfer-v1',createdAt:new Date().toISOString(),projectNumber:fields.projectNumber,fields:out};
  diagnostic.readSource='fallback';
  diagnostic.fieldKeys=Object.keys(out);
  return {payload,diagnostic};
}

async function refreshFromScoping(){
  let detection = null;
  try { detection = await selectConfirmedScopingTab(); } catch (err) {
    const detail=`Could not inspect Scoping Assistant tabs: ${err?.message || String(err)}`;
    await chrome.storage.local.set({scopingStatus:{ready:false,detail,diagnostic:{stage:'recognition',error:err?.message || String(err)}}});
    return {ok:false,error:detail};
  }
  const sel = detection?.selected;
  if(!sel){
    const detail='No Scoping Assistant tab with confirmed project data found.';
    await chrome.storage.local.set({scopingStatus:{ready:false,detail,diagnostic:{stage:'recognition',...detection}}});
    await notifyPanel();
    return {ok:false,error:detail,diagnostic:{stage:'recognition',...detection}};
  }

  const tabDiagnostic={
    stage:'executeScript',
    tabId:sel.id,
    windowId:sel.windowId ?? null,
    tabIndex:sel.index ?? null,
    tabUrl:String(sel.url || ''),
    tabTitle:String(sel.title || ''),
    scannedTabs:detection.inspected.length,
    rejectedTabs:detection.rejected.length,
    recognition:'presence-confirmed'
  };

  const read=await readWithTimeout(sel.id);
  if(!read.ok){
    const diagnostic={...tabDiagnostic,stage:'executeScript_error',error:read.error};
    const detail=`Scoping Assistant found, but could not be read: ${read.error}`;
    await chrome.storage.local.set({scopingStatus:{ready:false,detail,diagnostic}});
    await notifyPanel();
    return {ok:false,error:detail,diagnostic};
  }

  const readResult=read.result;
  const payload=readResult?.payload;
  const diagnostic={...tabDiagnostic,...(readResult?.diagnostic || {})};

  if(!payload?.schema || !payload?.projectNumber){
    const detail='Scoping Assistant found, but no project number is ready for transfer.';
    diagnostic.stage='validation';
    await chrome.storage.local.set({scopingStatus:{ready:false,detail,diagnostic}});
    await notifyPanel();
    return {ok:false,error:detail,diagnostic};
  }

  diagnostic.stage='success';
  const fieldCount=diagnostic.fieldKeys?.length || Object.keys(payload.fields || {}).length;
  const detail=`Project ${payload.projectNumber} read from Scoping Assistant. Source: ${diagnostic.readSource || 'unknown'} • ${fieldCount} field${fieldCount===1?'':'s'} • Tab ${diagnostic.tabId} • Navigation: ${diagnostic.navigationType || 'unknown'}`;
  await chrome.storage.local.set({pendingTransfer:payload,lastTransfer:null,scopingStatus:{ready:true,detail,diagnostic}});
  await notifyPanel();
  return {ok:true,payload,diagnostic};
}

async function findAnvilTab(){
  const tabs = await chrome.tabs.query({url:['https://atcotrafficcontrol.anvil.app/*']});
  return tabs.find(t => t.active) || tabs[0] || null;
}

async function findScopingUrlTab(){
  const {candidates}=await getScopingCandidates();
  return candidates[0] || null;
}

async function openOrFocusScoping(){
  const existing = await findScopingUrlTab();
  if(existing?.id){
    await chrome.tabs.update(existing.id,{active:true});
    return existing;
  }
  return await chrome.tabs.create({url:'https://telecom-infra.github.io/scoping-assistant-site/'});
}

async function openOrFocusAnvil(){
  const existing = await findAnvilTab();
  if(existing?.id){
    await chrome.tabs.update(existing.id,{active:true});
    return existing;
  }
  return await chrome.tabs.create({url:ANVIL_URL});
}

async function handleScopingTransfer(payload){
  if(!payload || payload.schema !== 'ATCO-Anvil-Transfer-v1') throw new Error('Invalid ATCO transfer package.');
  await chrome.storage.local.set({pendingTransfer: payload, lastTransfer:null, scopingStatus:{ready:true,detail:`Project ${payload.projectNumber || '[No project #]'} ready from the Scoping Assistant.`}});
  await openOrFocusAnvil();
  await notifyPanel();
}

async function transferInAnvil(fields){
  const norm = v => String(v ?? '').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim().toLowerCase().replace(/:$/,'').replace(/ ?([\/\-(]) ?/g,'$1');
  const normalizeOptionText = v => String(v ?? '').trim().replace(/\s+/g,' ').replace(/\s*-\s*/g,'-').toLowerCase();
  const visible = el => { if(!el) return false; const r = el.getBoundingClientRect(); return r.width>0 && r.height>0; };
  const readValue = (c, type) => { try { return type==='select' ? String(c.options?.[c.selectedIndex]?.text ?? '') : String(c.value ?? ''); } catch { return ''; } };
  const MAPPINGS = [
    { key:'projectNumber',      label:'Project Number',            type:'input',    fmt:v=>v },
    { key:'altProjectNumber',   label:'Alternate Project Number',  type:'input',    fmt:v=>v },
    { key:'projectAddress',     label:'Project Address/Description',type:'input',   fmt:v=>v },
    { key:'dateReceived',       label:'Date Received',              type:'input',    fmt:v=>{ const m=String(v).match(/^(\d{4})-(\d{2})-(\d{2})$/); return m?`${Number(m[2])}/${Number(m[3])}/${m[1]}`:String(v); } },
    { key:'customer',           label:'Customer',                   type:'select',   fmt:v=>v },
    { key:'scope',              label:'Work Type',                  type:'select',   fmt:v=>v },
    { key:'exchange',           label:'Exchange',                   type:'select',   fmt:v=>v },
    { key:'scoperNotes',        label:'Notes',                      type:'textarea', fmt:v=>v }
  ];
  // Deterministic resolver: pinned label -> exact match first, else single-container
  // includes-match. Anvil nests field gutters, so an ancestor gutter can carry the
  // same label as its leaf (its subtree holds the whole remaining form): we walk to
  // the SMALLEST matching container, and break any remaining same-size tie by the
  // pinned control type (preference, not filter). Control level prefers the visible
  // control but a lone off-screen one (e.g. a collapsed Notes textarea) is accepted.
  const resolveField = (wantedLabel, pref) => {
    const wanted = norm(wantedLabel);
    const prefTag = pref === 'select' ? 'SELECT' : pref === 'textarea' ? 'TEXTAREA' : 'INPUT';
    const inventory = () => [...document.querySelectorAll('.flow-panel-gutter')].slice(0, 40).map(g => {
      const lab = String(g.querySelector('.label-text')?.textContent || '').trim();
      const tags = [...g.querySelectorAll('input, select, textarea')].map(c => c.tagName.toLowerCase());
      return lab ? `${lab}(${tags.join(',')})` : null;
    }).filter(Boolean).join(' | ');
    const controlCount = g => g.querySelectorAll('input, select, textarea').length;
    let matches = [], bestScore = 0;
    for (const gutter of document.querySelectorAll('.flow-panel-gutter')) {
      const labelEl = gutter.querySelector('.label-text');
      if (!labelEl) continue;
      const text = norm(labelEl.textContent);
      const eq = text === wanted;
      const annotated = text.startsWith(wanted) && (text.length === wanted.length || /^[ (]/.test(text.slice(wanted.length)));
      const score = eq ? 3 : (annotated ? 2 : 0);
      if (score === 0) continue;
      if (score > bestScore) { bestScore = score; matches = [gutter]; }
      else if (score === bestScore) matches.push(gutter);
    }
    if (!matches.length) return { ok:false, reason:`Field not found by label: "${wantedLabel}". Gutters seen: ${inventory()}` };
    let candidates = matches.filter(g => controlCount(g) === Math.min(...matches.map(controlCount)));
    const typed = candidates.filter(g => [...g.querySelectorAll('input, select, textarea')].some(c => c.tagName === prefTag));
    if (typed.length === 1) candidates = typed;
    if (candidates.length > 1) return { ok:false, reason:`Ambiguous: multiple containers match "${wantedLabel}"` };
    const best = candidates[0];
    const labelText = String(best.querySelector('.label-text')?.textContent || '').trim();
    const all = [...best.querySelectorAll('input, select, textarea')];
    let controls = all.filter(c => c.tagName === prefTag);
    if (!controls.length) controls = all;
    if (!controls.length) return { ok:false, reason:`No form control in container "${labelText}"` };
    const onscreen = controls.filter(visible);
    let control = null, vis = false;
    if (onscreen.length === 1) { control = onscreen[0]; vis = true; }
    else if (controls.length === 1) { control = controls[0]; vis = false; }
    else return { ok:false, reason:`Multiple controls in container "${labelText}"` };
    return { ok:true, control, controlType:control.tagName, mode:bestScore===3?'exact':'includes', visible:vis, labelText };
  };
  const writeValue = (c, type, value) => {
    c.focus();
    if (type === 'select') {
      const wanted = normalizeOptionText(value);
      const options = [...c.options];
      let opt = options.find(o => normalizeOptionText(o.text) === wanted);
      if (!opt) {
        const code = (String(value).match(/\b\d{5}\b/)||[])[0];
        const clli = (String(value).match(/\b[A-Za-z]{4}\b/)||[])[0]?.toLowerCase();
        if (code) opt = options.find(o => String(o.text).replace(/\s+/g,' ').includes(code));
        if (!opt && clli) opt = options.find(o => String(o.text).toLowerCase().includes(clli));
      }
      if (!opt) return { ok:false, reason:`Option not found: "${value}"` };
      c.value = opt.value;
      c.dispatchEvent(new Event('input',{bubbles:true}));
      c.dispatchEvent(new Event('change',{bubbles:true}));
      c.dispatchEvent(new Event('blur',{bubbles:true}));
      return { ok:true, written:opt.text, expectation:opt.text };
    }
    const set = String(value ?? '');
    const proto = (typeof HTMLTextAreaElement !== 'undefined' && c.tagName === 'TEXTAREA')
      ? HTMLTextAreaElement.prototype
      : (typeof HTMLInputElement !== 'undefined' ? HTMLInputElement.prototype : null);
    const setter = proto ? Object.getOwnPropertyDescriptor(proto,'value')?.set : null;
    if (setter) setter.call(c, set); else c.value = set;
    c.dispatchEvent(new Event('input',{bubbles:true}));
    c.dispatchEvent(new Event('change',{bubbles:true}));
    c.dispatchEvent(new Event('blur',{bubbles:true}));
    return { ok:true, written:set, expectation:set };
  };
  const verify = (c, type, expectation) => {
    try { return norm(readValue(c, type)) === norm(String(expectation ?? '')); }
    catch { return false; }
  };
  if (!resolveField('Project Number', 'input').ok) {
    return { ok:false, count:0, failed:0, skipped:0, results:[], error:'The Anvil Create Project form was not detected.' };
  }
  const results = [];
  let transferred = 0, failed = 0, skipped = 0;
  for (const { key,label,type,fmt } of MAPPINGS) {
    if (!(key in fields)) continue;
    const base = { key, label };
    const raw = fields[key];
    if (String(raw ?? '').trim() === '') {
      results.push({ ...base, status:'skipped', ok:false, skipped:true, error:'Blank value' });
      skipped++;
      continue;
    }
    const value = fmt(raw);
    const resolved = resolveField(label, type);
    if (!resolved.ok) {
      results.push({ ...base, status:'unmatched', ok:false, error:resolved.reason });
      failed++;
      continue;
    }
    let written;
    try { written = writeValue(resolved.control, type, value); }
    catch (err) { written = { ok:false, reason:err?.message || String(err) }; }
    if (!written.ok) {
      results.push({ ...base, status:'write_failed', ok:false, error:written.reason, matched:resolved.mode, controlType:resolved.controlType });
      failed++;
      continue;
    }
    if (!verify(resolved.control, type, written.expectation)) {
      results.push({ ...base, status:'verify_failed', ok:false, error:'Write did not stick (readback mismatch)', matched:resolved.mode, controlType:resolved.controlType, written:written.written, readback:readValue(resolved.control, type) });
      failed++;
      continue;
    }
    results.push({ ...base, status:'ok', ok:true, matched:resolved.mode, controlType:resolved.controlType, visibility:resolved.visible?'ok':'fallback', value:written.written, verified:true });
    transferred++;
    await new Promise(r => setTimeout(r, 180));
  }
  return {
    ok: failed === 0,
    count: transferred,
    failed,
    skipped,
    results,
    note: 'Fields were populated by the ATCO transfer test. Review the Anvil form before creating the project.'
  };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async()=>{
    try{
      if(msg?.type === 'SCOPING_TRANSFER_READY'){
        await handleScopingTransfer(msg.payload);
        sendResponse({ok:true});
        return;
      }
      if(msg?.type === 'GET_STATE'){
        sendResponse(await getState());
        return;
      }
      if(msg?.type === 'SET_SELECTIONS'){
        const clean={};
        for(const key of FIELD_KEYS) clean[key] = msg.selections?.[key] !== false;
        await chrome.storage.local.set({selections:clean});
        sendResponse({ok:true});
        return;
      }
      if(msg?.type === 'OPEN_SCOPING'){
        await openOrFocusScoping();
        sendResponse({ok:true});
        return;
      }
      if(msg?.type === 'OPEN_ANVIL'){
        await openOrFocusAnvil();
        sendResponse({ok:true});
        return;
      }
      if(msg?.type === 'ANVIL_STATUS'){
        await chrome.storage.local.set({anvilStatus:{ready:!!msg.ready,detail:msg.detail||''}});
        await notifyPanel();
        sendResponse({ok:true});
        return;
      }
      if(msg?.type === 'RUN_REFRESH_DIAGNOSTIC'){
        const diagnostic=await runRefreshDiagnostics();
        await chrome.storage.local.set({scopingDiagnostic:diagnostic});
        await notifyPanel();
        sendResponse({ok:true,diagnostic});
        return;
      }
      if(msg?.type === 'REFRESH_FROM_SCOPING'){
        const r=await refreshFromScoping();
        sendResponse(r);
        return;
      }
      if(msg?.type === 'TRANSFER_NOW'){
        const tab = await findAnvilTab();
        if(!tab?.id){sendResponse({ok:false,error:'Open the Anvil Create Project page first.'});return;}
        const data = await chrome.storage.local.get(['pendingTransfer','selections']);
        if(!data.pendingTransfer){sendResponse({ok:false,error:'No project transfer package is loaded.'});return;}
        const selectedFields={};
        for(const key of FIELD_KEYS){
          if(data.selections?.[key] !== false && data.pendingTransfer.fields?.[key] !== undefined){
            selectedFields[key]=data.pendingTransfer.fields[key];
          }
        }
        let result;
        try {
          const injected = await chrome.scripting.executeScript({
            target:{tabId:tab.id},
            func:transferInAnvil,
            args:[selectedFields]
          });
          result = injected?.[0]?.result || {ok:false,error:'No result returned from the Anvil page.'};
        } catch (err) {
          result = {ok:false,error:`Could not run transfer on the Anvil page: ${err?.message || String(err)}`};
        }
        const stamped = {...result,timestamp:new Date().toISOString()};
        await chrome.storage.local.set({lastTransfer:stamped});
        await notifyPanel();
        sendResponse(stamped);
        return;
      }
      if(msg?.type === 'CLEAR_PENDING_TRANSFER'){
        await chrome.storage.local.remove(['pendingTransfer','lastTransfer']);
        await notifyPanel();
        sendResponse({ok:true});
        return;
      }
      sendResponse({ok:false,error:'Unknown message.'});
    }catch(err){
      sendResponse({ok:false,error:err?.message||String(err)});
    }
  })();
  return true;
});