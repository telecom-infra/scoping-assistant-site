const FIELD_DEFS=[
  ['projectNumber','Project Number'],['altProjectNumber','Alternate Project Number'],['projectAddress','Project Address / Description'],
  ['dateReceived','Date Received'],['customer','Customer'],['scope','Work Type'],['exchange','Exchange'],['scoperNotes','Notes']
];
const state={payload:null,selections:{},anvil:{ready:false,detail:''},lastTransfer:null,scoping:{ready:false,detail:''},scopingDiagnostic:null};
function send(msg){return chrome.runtime.sendMessage(msg)} function el(id){return document.getElementById(id)} function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))} function selectedCount(){return FIELD_DEFS.filter(([k])=>state.selections[k]).length}
async function load(){const r=await send({type:'GET_STATE'});state.payload=r?.pendingTransfer||null;state.selections=r?.selections||Object.fromEntries(FIELD_DEFS.map(([k])=>[k,true]));state.anvil=r?.anvil||{ready:false,detail:''};state.lastTransfer=r?.lastTransfer||null;state.scoping=r?.scoping||{ready:false,detail:''};state.scopingDiagnostic=r?.scopingDiagnostic||null;render()}
function render(){
  const p=state.payload; const s=state.anvil; const status=el('anvilStatus'); const detail=el('anvilDetail');
  status.textContent=s.ready?'✓ Create Project page detected':'Waiting for Anvil'; status.className='status '+(s.ready?'ok':'warn'); detail.textContent=s.detail||'Open the Anvil Create Project page.';
  const sc=state.scoping;
  const scopingStatus=el('scopingStatus');
  if(scopingStatus){scopingStatus.textContent=sc.ready?'✓ Scoping Assistant project detected':'Waiting for Scoping Assistant'; scopingStatus.className='status '+(sc.ready?'ok':'warn');}
  const scopingMeta=el('scopingMeta');
  if(scopingMeta){scopingMeta.textContent=sc.detail||'Looking for an open Scoping Assistant project.'; scopingMeta.className='detail '+(sc.ready?'okText':'');}
  const diagWrap=el('scopingDiagnosticWrap'); const diag=el('scopingDiagnostic');
  if(diagWrap&&diag){
    const d=state.scopingDiagnostic || sc.diagnostic || null;
    const parts=[];
    if(d?.startedAt) parts.push(`Started: ${d.startedAt}`);
    if(d?.finishedAt) parts.push(`Finished: ${d.finishedAt}`);
    if(d?.inspected?.length!==undefined) parts.push(`Candidates: ${d.inspected.length}${d.rejected?.length?` (${d.rejected.length} rejected)`:''}`);
    if(d?.inspected?.length) d.inspected.forEach(t=>{
      if(t.probe?.ok){const r=t.probe.result||{};parts.push(`Tab ${t.id} ${t.active?'(active) ':''}OK • project=${r.projectValue||'blank'} • fields=${r.transferFieldCount??0} • nav=${r.navigationType||'unknown'}`);}
      else{parts.push(`Tab ${t.id} PROBE ✕ ${t.probe?.error||'unknown error'}`);}
    });
    if(d?.rejected?.length) d.rejected.forEach(r=>parts.push(`Rejected ${r.id??''}: ${esc(r.reason||r.error||'no reason')}`));
    if(d?.selected){
      parts.push(`Selected tab: ${d.selected.id} • presence ok (${d.selected.reason||''})`);
      if(d.selected.presence){const pr=d.selected.presence;parts.push(`Presence: project=${pr.projectValue||'blank'} • fields=${pr.transferFieldCount??0} • nav=${pr.navigationType||'unknown'}`);}
    }else if(!d?.error){parts.push('Selected tab: none');}
    if(d?.isolatedRead){parts.push(d.isolatedRead.ok?`ISOLATED read: source=${d.isolatedRead.result?.diagnostic?.readSource||'unknown'} • fields=${(d.isolatedRead.result?.diagnostic?.fieldKeys||[]).join(', ')||'none'}`:`ISOLATED read ✕ ${esc(d.isolatedRead.error||'')}`);}
    if(d?.mainProbe){parts.push(d.mainProbe.ok?`MAIN probe: project=${d.mainProbe.result?.projectValue||'blank'} • fields=${d.mainProbe.result?.transferFieldCount??0}`:`MAIN probe ✕ ${esc(d.mainProbe.error||'')}`);}
    if(d?.mainRead){parts.push(d.mainRead.ok?`MAIN read: source=${d.mainRead.result?.diagnostic?.readSource||'unknown'} • fields=${(d.mainRead.result?.diagnostic?.fieldKeys||[]).join(', ')||'none'}`:`MAIN read ✕ ${esc(d.mainRead.error||'')}`);}
    if(d?.error) parts.push(`Diagnostic error: ${d.error}`);
    if(!parts.length) parts.push('No diagnostic run yet.');
    diag.textContent=parts.join('\n');
    diag.style.whiteSpace='pre-line';
    diagWrap.style.display='block';
  }
  el('projectMeta').textContent=p?`Project ${p.projectNumber||'[No project #]'} • Transfer package received`:'Waiting for a project from the Scoping Assistant.';
  el('fieldCount').textContent=`${selectedCount()} selected`;
  el('fieldList').innerHTML=FIELD_DEFS.map(([key,label])=>{const value=p?.fields?.[key]??'';const checked=state.selections[key]!==false;return `<label class="field ${value===''?'empty':''}"><input type="checkbox" data-field="${esc(key)}" ${checked?'checked':''} ${p?'':'disabled'}><span><span class="name">${esc(label)}</span><br><span class="value">${esc(value||'Blank in Scoping Assistant')}</span></span></label>`}).join('');
  el('transfer').disabled=!p||!s.ready||selectedCount()===0;
  const tm=el('transferMessage'); if(!p){tm.className='message muted';tm.textContent='Use “Create New Project in Anvil” in the Scoping Assistant.'} else if(!s.ready){tm.className='message warn';tm.textContent='Transfer package received. Open the Anvil Create Project page before transferring.'} else {tm.className='message ok';tm.textContent='Project and Anvil form are ready. Review the selected fields, then transfer.'}
  renderResults();
}
function renderResults(){const box=el('resultList');const r=state.lastTransfer;if(!r){box.innerHTML='';return}
  const detailOf=x=>{
    if(x.skipped) return 'blank value — skipped';
    if(x.ok) return `${x.matched||'matched'}${x.visibility==='fallback'?' via hidden-control fallback':''} • ${x.verified?'verified':'written'}`;
    return `${x.status||'failed'}: ${esc(x.error||'')}`;
  };
  const rows=(r.results||[]).map(x=>`<div class="result"><span class="result-icon ${x.skipped?'result-skip':x.ok?'result-ok':'result-bad'}">${x.skipped?'⚠':x.ok?'✓':'✕'}</span><span><b>${esc(x.label)}</b><br><span class="detail">${detailOf(x)}</span></span></div>`).join('');
  const cls=r.ok?'ok':'warn';
  box.innerHTML=`<div class="message ${cls}"><b>${r.count||0} field${(r.count||0)===1?'':'s'} transferred</b>${r.failed?` • ${r.failed} failed`:''}${r.skipped?` • ${r.skipped} skipped`:''}</div>${rows}<div class="detail" style="margin-top:6px">Review the Anvil form before creating the project.</div>`;}
el('fieldList').addEventListener('change',async e=>{if(!e.target.matches('[data-field]'))return;state.selections[e.target.dataset.field]=e.target.checked;await send({type:'SET_SELECTIONS',selections:state.selections});render()});
el('selectAll').addEventListener('click',async()=>{Object.keys(state.selections).forEach(k=>state.selections[k]=true);await send({type:'SET_SELECTIONS',selections:state.selections});render()});
el('deselectAll').addEventListener('click',async()=>{Object.keys(state.selections).forEach(k=>state.selections[k]=false);await send({type:'SET_SELECTIONS',selections:state.selections});render()});
if(el('openScoping')) el('openScoping').addEventListener('click',async e=>{
  e.preventDefault();
  const b=el('openScoping');
  b.textContent='Opening…'; b.disabled=true;
  try{ await send({type:'OPEN_SCOPING'}); }
  finally{ b.textContent='Launch Scoping Assistant'; b.disabled=false; }
});
// Open ATCO Portal is a direct link; no service-worker navigation required.
if(el('runDiagnostic')) el('runDiagnostic').addEventListener('click',async()=>{
  el('runDiagnostic').disabled=true;
  el('runDiagnostic').textContent='Running…';
  try{
    const r=await send({type:'RUN_REFRESH_DIAGNOSTIC'});
    state.scopingDiagnostic=r?.diagnostic||{error:r?.error||'No diagnostic returned.'};
    render();
  }catch(err){
    state.scopingDiagnostic={error:err?.message||String(err)};
    render();
  }finally{
    el('runDiagnostic').disabled=false;
    el('runDiagnostic').textContent='Run Refresh Diagnostic';
  }
});
if(el('refreshScoping')) el('refreshScoping').addEventListener('click',async()=>{
  el('refreshScoping').disabled=true;
  try{
    const r=await send({type:'REFRESH_FROM_SCOPING'});
    if(r&&!r.ok){state.scoping={ready:false,detail:r.error||'Refresh failed.',diagnostic:r.diagnostic||null};if(r.diagnostic)state.scopingDiagnostic=r.diagnostic;render()}
    else{await load()}
  }catch(err){
    state.scoping={ready:false,detail:`Refresh request failed: ${err?.message||String(err)}`,diagnostic:{error:err?.message||String(err)}};
    state.scopingDiagnostic=state.scoping.diagnostic;
    render();
  }finally{el('refreshScoping').disabled=false;}
});
el('transfer').addEventListener('click',async()=>{el('transfer').disabled=true;const r=await send({type:'TRANSFER_NOW'});state.lastTransfer=r||null;render()});
chrome.runtime.onMessage.addListener(msg=>{if(msg?.type==='STATE_UPDATED')load()});load();setInterval(load,1500);