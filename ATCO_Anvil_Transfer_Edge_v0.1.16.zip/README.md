# ATCO Anvil Transfer v0.1.16 — Deterministic Anvil field fill

Small companion browser extension for transferring finalized Scoping Assistant project values into the ATCO Anvil Create Project form.

## ATCO Portal
https://atcotrafficcontrol.anvil.app/

## Live Scoping Assistant
https://telecom-infra.github.io/scoping-assistant-site/

## Workflow
1. Build/review the project in the Scoping Assistant.
2. Use **Create New Project in Anvil** in the Scoping Assistant or refresh from the open Scoping Assistant tab.
3. Open the ATCO Anvil Transfer side panel.
4. Confirm the project is detected.
5. Choose fields to transfer.
6. Click **Transfer Selected Fields**.
7. Review the populated Anvil form, upload files, complete anything missing, and create the project manually.

The extension does not click Anvil's Create Project button.

## v0.1.16 changes
- Fixed field resolution on the real Anvil DOM, which **nests field gutters**: an ancestor gutter carries the same label as the leaf field because its subtree wraps the whole remaining form. The resolver previously saw these as an ambiguous tie and refused (this is what broke Project Address/Description, Date Received, and Exchange).
- The resolver now walks to the **smallest matching container** (the leaf that actually holds the field's control), and breaks any remaining same-size label tie by the pinned control type — so the two real `Exchange:` fields (a hidden `input` and the actual `select`) resolve to the select deterministically.
- Validated against a live snapshot of the actual Anvil form before this build was made (see tests/run-anvil-snapshot.mjs).

## v0.1.15 changes (preserved)
- Resolver control *type* is now a preference, not a hard filter. If a matched field gutter (e.g. Project Address/Description) is rendered as a `<textarea>` instead of the pinned `<input>`, the single form control inside the gutter is still used. This fixes the address field when Anvil renders it as a textarea.
- Unmatched fields now include a short **gutter inventory** (label + control tag) in the error, so a failure names exactly what Anvil rendered — no console digging needed.
- Still deterministic: a tie between containers or multiple controls inside one container is reported, never guessed.

## v0.1.14 changes (preserved)
- Label normalization now also collapses spacing around punctuation (`/`, `-`, `(`). This makes `Project Address / Description` and `Project Address/Description` match the same pinned field, so the address field populates regardless of Anvil's slash spacing.
- Build on the v0.1.13 deterministic resolver (no other matching behavior changed).

## v0.1.13 changes (preserved)
- Anvil field resolution is now deterministic: each field has a pinned label (Alternate Project Number → `input`, Notes → `textarea`) matched **exactly first**, with a single-container includes fallback. An unresolved, ambiguous, or multi-control container is reported per field instead of failing silently.
- A lone off-screen control (e.g. a collapsed Notes textarea) is accepted through the same code path instead of being rejected for failing a size test.
- Every field now carries an audit trail: **captured → matched → written → verified**. Each per-field result reports the match mode (`exact`/`includes`), whether the hidden-control fallback was used, and a readback check; failures name the failing stage and reason.
- The side panel lists each field outcome (✓ / ⚠ / ✕) with its stage detail, so Alternate Project Number and Notes can no longer drop out invisibly.
- The same resolver + verify pipeline is mirrored in the injected service-worker fill and `anvil_content.js`.

## v0.1.12 changes (preserved)
- Recognition is now a two-step, verification-based process instead of a URL/title guess:
  1. Strict candidate filtering.
  2. Per-candidate ISOLATED presence probe (8s timeout), requiring a `#project` element and transfer fields before a tab can be selected.
- GitHub Pages matches use an exact host + path check (`https://telecom-infra.github.io/scoping-assistant-site/...`).
- `file://` and `localhost` tabs are accepted only when the tab title contains "ATCO Scoping Assistant".
- The `candidates[0]` fallback has been removed entirely; no tab is selected without a confirmed presence probe.
- Every read/probe step runs under an 8s timeout so a problem is reported as a timed-out stage instead of an indefinite hang.
- Refresh diagnostic reports: scanned candidates, per-tab presence probe results, rejected tabs with reasons, chosen tab, ISOLATED read, MAIN probe, and MAIN read.
- The same recognition path is used by the Refresh action, so a failed refresh now reports *why* (wrong tab / no app present / timeout) rather than a generic failure.
- Footer updated to identify this as the recognition diagnostic build.

## v0.1.11 changes (preserved)
- Adds Refresh diagnostics showing the selected tab, URL/title context, read source, field keys, and navigation type.
- Preserves the existing v0.1.9 read path for testing; no reader behavior change is introduced.
- Keeps GitHub Pages access and the live Scoping Assistant message bridge.

## Available transfer fields
Project Number, Alternate Project Number, Project Address / Description, Date Received, Customer, Work Type, Exchange, and Notes.

Not mapped yet: Assigned To, CLLI Code, Engineer, OSP Engineering Manager, Engineering Coordinator, and Confirmed Permit Jurisdiction.

Edge remains the primary tested browser for this beta. Chrome uses the same transfer logic and is packaged separately for validation.