# ATCO Anvil Transfer v0.1.6 — Edge beta

Small companion browser extension for transferring finalized Scoping Assistant project values into the ATCO Anvil Create Project form.

## ATCO Portal
https://atcotrafficcontrol.anvil.app/

## Workflow
1. Build/review the project in the Scoping Assistant.
2. Open the ATCO Portal and navigate to Create Project.
3. Open the ATCO Anvil Transfer side panel.
4. Confirm the project is detected.
5. Choose fields to transfer.
6. Click **Transfer Selected Fields**.
7. Review the populated Anvil form, upload files, complete anything missing, and create the project manually.

The extension does not click Anvil's Create Project button.

## v0.1.6 field status
Available transfer fields: Project Number, Alternate Project Number, Project Address / Description, Date Received, Customer, Work Type, Exchange, and Notes.

Not mapped yet: Assigned To, CLLI Code, Engineer, OSP Engineering Manager, Engineering Coordinator, and Confirmed Permit Jurisdiction.

## Local Scoping Assistant
The extension can refresh the current project directly from an open local `file://` or `http://localhost/`, `http://127.0.0.1/`, or HTTPS localhost/127.0.0.1 Scoping Assistant tab. For local files, Edge/Chrome may require **Allow access to file URLs** in the extension details.

## Testing focus
Edge remains the primary test browser for this beta. Chrome uses the same transfer logic and is packaged separately for later validation.


## Local preview note
The extension can access a Scoping Assistant served in an actual Edge/Chrome tab on localhost/127.0.0.1 or a local `file://` tab. A Scoping Assistant shown only inside VS Code's embedded Live Preview webview is not a browser tab and cannot be read by the browser extension. Use Live Preview's external-browser option when testing the extension.


## v0.1.6 refresh fix
Refresh now prioritizes the active Edge/Chrome tab and verifies the page by its Scoping Assistant DOM before reading project data. Refresh errors are surfaced in the side panel.


## v0.1.7

- Restores the v0.1.3-style Scoping Assistant tab discovery path.
- Supports local file/localhost/127.0.0.1 Scoping Assistant pages.
- Uses a direct link for the ATCO Portal: https://atcotrafficcontrol.anvil.app/
- Assigned To remains unmapped.
