const ANVIL_URL = 'https://atcotrafficcontrol.anvil.app/';
const FIELD_KEYS = [
  'projectNumber','altProjectNumber','projectAddress','dateReceived',
  'customer','scope','exchange','scoperNotes'
];
const defaultSelections = Object.fromEntries(FIELD_KEYS.map(k => [k, true]));

chrome.runtime.onInstalled.addListener(async () => {
  const current = await chrome.storage.local.get(['selections']);
  if (!current.selections) await chrome.storage.local.set({selections: defaultSelections});
  if (!current.scopingStatus) await chrome.storage.local.set({scopingStatus:{ready:false,detail:'Looking for an open Scoping Assistant project.'}});
});

async function getState(){
  const s = await chrome.storage.local.get(['pendingTransfer','selections','anvilStatus','lastTransfer','scopingStatus']);
  return {
    pendingTransfer: s.pendingTransfer || null,
    selections: s.selections || defaultSelections,
    anvil: s.anvilStatus || {ready:false,detail:'Open Anvil → Create Project.'},
    lastTransfer: s.lastTransfer || null,
    scoping: s.scopingStatus || {ready:false,detail:'Looking for an open Scoping Assistant project.'}
  };
}

async function notifyPanel(){
  try { await chrome.runtime.sendMessage({type:'STATE_UPDATED'}); } catch (_) {}
}



function isLocalScopingUrl(rawUrl){
  try{
    const u=new URL(String(rawUrl || ''));
    if(u.protocol === 'file:') return true;
    if(!['http:','https:'].includes(u.protocol)) return false;
    return u.hostname === 'localhost' || u.hostname === '127.0.0.1';
  }catch(_){
    return false;
  }
}

async function findScopingTab(){
  const tabs = await chrome.tabs.query({});
  const active = tabs.find(t => t.active) || null;
  const candidates = [
    ...(active ? [active] : []),
    ...tabs.filter(t => t.id !== active?.id)
  ].filter(t => {
    const title = String(t.title || '').toLowerCase();
    const url = String(t.url || '');
    return title.includes('atco scoping assistant') || isLocalScopingUrl(url);
  });
  return candidates.find(t => String(t.title || '').toLowerCase().includes('atco scoping assistant')) || candidates[0] || null;
}
function readScopingProject(){
  const clean=v => String(v ?? '').trim();
  const normalizedAddress = () => {
    const v=document.getElementById('address')?.value || '';
    return String(v).trim().replace(/[\n\r\t]+/g,' ').replace(/\s+/g,' ').replace(/\s*,\s*/g,', ').replace(/,+/g,',').replace(/^,|,$/g,'');
  };
  try{
    if(typeof window.getTransferPayload === 'function') return window.getTransferPayload();
  }catch(_){ }
  const fields={
    projectNumber: clean(document.getElementById('project')?.value),
    altProjectNumber: clean(document.getElementById('altProjectNumber')?.value),
    projectAddress: normalizedAddress(),
    dateReceived: clean(document.getElementById('received')?.value),
    customer: clean(document.getElementById('client')?.value || 'Ziply'),
    scope: clean(document.getElementById('scope')?.value),
    exchange: clean(document.getElementById('exchange')?.value),
    clli: clean(document.getElementById('clli')?.value),
    engineer: clean(document.getElementById('engineer')?.value),
    exchangeManager: clean(document.getElementById('exchangeManager')?.value),
    coordinator: clean(document.getElementById('coordinator')?.value),
    selectedJurisdiction: clean(document.getElementById('selectedJurisdiction')?.value),
    assignedCoordinator: clean(document.getElementById('assignedCoordinator')?.value),
    scoperNotes: clean(document.getElementById('scoperNotes')?.value)
  };
  const checkboxes=[...document.querySelectorAll('[data-transfer-field]')];
  const selected = checkboxes.length ? Object.fromEntries(checkboxes.map(cb=>[cb.dataset.transferField, !!cb.checked])) : {};
  const out={};
  for(const [k,v] of Object.entries(fields)) if(!checkboxes.length || selected[k] !== false) out[k]=v;
  return {schema:'ATCO-Anvil-Transfer-v1',createdAt:new Date().toISOString(),projectNumber:fields.projectNumber,fields:out};
}

async function refreshFromScoping(){
  let tab = null;
  try { tab = await findScopingTab(); } catch (err) {
    const detail=`Could not inspect Scoping Assistant tabs: ${err?.message || String(err)}`;
    await chrome.storage.local.set({scopingStatus:{ready:false,detail}});
    return {ok:false,error:detail};
  }
  if(!tab?.id){
    await chrome.storage.local.set({scopingStatus:{ready:false,detail:'No Scoping Assistant tab found.'}});
    return {ok:false,error:'No Scoping Assistant tab found.'};
  }
  try{
    const injected=await chrome.scripting.executeScript({target:{tabId:tab.id},func:readScopingProject});
    const payload=injected?.[0]?.result;
    if(!payload?.schema || !payload?.projectNumber){
      await chrome.storage.local.set({scopingStatus:{ready:false,detail:'Scoping Assistant found, but no project number is ready for transfer.'}});
      return {ok:false,error:'No completed project transfer data found in the Scoping Assistant.'};
    }
    await chrome.storage.local.set({pendingTransfer:payload,lastTransfer:null,scopingStatus:{ready:true,detail:`Project ${payload.projectNumber} ready from the Scoping Assistant.`}});
    await notifyPanel();
    return {ok:true,payload};
  }catch(err){
    const detail=`Scoping Assistant found, but could not read it: ${err?.message || String(err)}`;
    await chrome.storage.local.set({scopingStatus:{ready:false,detail}});
    return {ok:false,error:detail};
  }
}

async function findAnvilTab(){
  const tabs = await chrome.tabs.query({url:['https://atcotrafficcontrol.anvil.app/*']});
  return tabs.find(t => t.active) || tabs[0] || null;
}

async function openOrFocusAnvil(){
  const existing = await findAnvilTab();
  if(existing?.id){
    await chrome.tabs.update(existing.id,{active:true});
    return existing;
  }
  return await chrome.tabs.create({url:ANVIL_URL});
}

async function handleScopingTransfer(payload){
  if(!payload || payload.schema !== 'ATCO-Anvil-Transfer-v1') throw new Error('Invalid ATCO transfer package.');
  await chrome.storage.local.set({pendingTransfer: payload, lastTransfer:null, scopingStatus:{ready:true,detail:`Project ${payload.projectNumber || '[No project #]'} ready from the Scoping Assistant.`}});
  await openOrFocusAnvil();
  await notifyPanel();
}

async function transferInAnvil(fields){
  const norm = v => String(v ?? '').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim().toLowerCase().replace(/:$/,'');
  const visible = el => {
    if(!el) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  };
  const controlForLabel = (label, preferred) => {
    const wanted = norm(label);
    const matches = [];
    for (const gutter of document.querySelectorAll('.flow-panel-gutter')) {
      const labelEl = gutter.querySelector('.label-text');
      if (!labelEl || norm(labelEl.textContent) !== wanted) continue;
      let controls = [...gutter.querySelectorAll('input, select, textarea')].filter(visible);
      if (preferred === 'select') controls = controls.filter(c => c.tagName === 'SELECT');
      if (preferred === 'textarea') controls = controls.filter(c => c.tagName === 'TEXTAREA');
      if (preferred === 'input') controls = controls.filter(c => c.tagName === 'INPUT');
      matches.push(...controls);
    }
    return matches[0] || null;
  };
  const nativeSet = (el, value) => {
    el.focus();
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) setter.call(el, value); else el.value = value;
    el.dispatchEvent(new Event('input', {bubbles:true}));
    el.dispatchEvent(new Event('change', {bubbles:true}));
    el.dispatchEvent(new Event('blur', {bubbles:true}));
  };
  const normalizeOptionText = v => String(v ?? '').trim().replace(/\s+/g,' ').replace(/\s*-\s*/g,'-').toLowerCase();
  const setInput = (label, value) => {
    const c = controlForLabel(label,'input');
    if (!c) return {ok:false,error:`Field not found: ${label}`};
    nativeSet(c, String(value ?? ''));
    return {ok:true,value:c.value};
  };
  const setTextarea = (label, value) => {
    const c = controlForLabel(label,'textarea');
    if (!c) return {ok:false,error:`Field not found: ${label}`};
    nativeSet(c, String(value ?? ''));
    return {ok:true,value:c.value};
  };
  const setSelect = (label, wanted) => {
    const c = controlForLabel(label,'select');
    if (!c) return {ok:false,error:`Dropdown not found: ${label}`};
    const target = normalizeOptionText(wanted);
    const options = [...c.options];
    let opt = options.find(o => normalizeOptionText(o.text) === target);
    if (!opt) {
      const code = (String(wanted).match(/\b\d{5}\b/) || [])[0];
      const clli = (String(wanted).match(/\b[A-Za-z]{4}\b/) || [])[0]?.toLowerCase();
      if (code) opt = options.find(o => String(o.text).replace(/\s+/g,' ').includes(code));
      if (!opt && clli) opt = options.find(o => String(o.text).toLowerCase().includes(clli));
    }
    if (!opt) return {ok:false,error:`Option not found: ${wanted}`};
    c.focus();
    c.value = opt.value;
    c.dispatchEvent(new Event('input',{bubbles:true}));
    c.dispatchEvent(new Event('change',{bubbles:true}));
    c.dispatchEvent(new Event('blur',{bubbles:true}));
    return {ok:true,selected:opt.text};
  };
  const fmtDate = v => {
    if (!v) return '';
    const m = String(v).match(/^(\d{4})-(\d{2})-(\d{2})$/);
    return m ? `${Number(m[2])}/${Number(m[3])}/${m[1]}` : String(v);
  };
  const mappings = [
    ['projectNumber','Project Number','input',v=>setInput('Project Number',v)],
    ['altProjectNumber','Alternate Project Number','input',v=>setInput('Alternate Project Number',v)],
    ['projectAddress','Project Address/Description','input',v=>setInput('Project Address/Description',v)],
    ['dateReceived','Date Received','input',v=>setInput('Date Received',fmtDate(v))],
    ['customer','Customer','select',v=>setSelect('Customer',v)],
    ['scope','Work Type','select',v=>setSelect('Work Type',v)],
    ['exchange','Exchange','select',v=>setSelect('Exchange',v)],
    ['scoperNotes','Notes','textarea',v=>setTextarea('Notes',v)]
  ];
  const projectInput = controlForLabel('Project Number','input');
  if (!projectInput) return {ok:false,count:0,results:[],error:'The Anvil Create Project form was not detected.'};
  const results=[];
  for (const [key,label,type,fn] of mappings) {
    if (!(key in fields)) continue;
    const value = fields[key];
    if (String(value ?? '').trim() === '') {
      results.push({key,label,ok:false,skipped:true,error:'Blank value'});
      continue;
    }
    try {
      const r = fn(value);
      results.push({key,label,type,...r});
    } catch (e) {
      results.push({key,label,type,ok:false,error:e?.message || String(e)});
    }
    await new Promise(r => setTimeout(r, 180));
  }
  const failed = results.filter(r=>!r.ok && !r.skipped);
  const skipped = results.filter(r=>r.skipped);
  return {
    ok: failed.length === 0,
    count: results.filter(r=>r.ok).length,
    failed: failed.length,
    skipped: skipped.length,
    results,
    note: 'Fields were populated by the ATCO transfer test. Review the Anvil form before creating the project.'
  };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async()=>{
    try{
      if(msg?.type === 'SCOPING_TRANSFER_READY'){
        await handleScopingTransfer(msg.payload);
        sendResponse({ok:true});
        return;
      }
      if(msg?.type === 'GET_STATE'){
        sendResponse(await getState());
        return;
      }
      if(msg?.type === 'SET_SELECTIONS'){
        const clean={};
        for(const key of FIELD_KEYS) clean[key] = msg.selections?.[key] !== false;
        await chrome.storage.local.set({selections:clean});
        sendResponse({ok:true});
        return;
      }
      if(msg?.type === 'OPEN_ANVIL'){
        await openOrFocusAnvil();
        sendResponse({ok:true});
        return;
      }
      if(msg?.type === 'ANVIL_STATUS'){
        await chrome.storage.local.set({anvilStatus:{ready:!!msg.ready,detail:msg.detail||''}});
        await notifyPanel();
        sendResponse({ok:true});
        return;
      }
      if(msg?.type === 'REFRESH_FROM_SCOPING'){
        const r=await refreshFromScoping();
        sendResponse(r);
        return;
      }
      if(msg?.type === 'TRANSFER_NOW'){
        const tab = await findAnvilTab();
        if(!tab?.id){sendResponse({ok:false,error:'Open the Anvil Create Project page first.'});return;}
        const data = await chrome.storage.local.get(['pendingTransfer','selections']);
        if(!data.pendingTransfer){sendResponse({ok:false,error:'No project transfer package is loaded.'});return;}
        const selectedFields={};
        for(const key of FIELD_KEYS){
          if(data.selections?.[key] !== false && data.pendingTransfer.fields?.[key] !== undefined){
            selectedFields[key]=data.pendingTransfer.fields[key];
          }
        }
        let result;
        try {
          const injected = await chrome.scripting.executeScript({
            target:{tabId:tab.id},
            func:transferInAnvil,
            args:[selectedFields]
          });
          result = injected?.[0]?.result || {ok:false,error:'No result returned from the Anvil page.'};
        } catch (err) {
          result = {ok:false,error:`Could not run transfer on the Anvil page: ${err?.message || String(err)}`};
        }
        const stamped = {...result,timestamp:new Date().toISOString()};
        await chrome.storage.local.set({lastTransfer:stamped});
        await notifyPanel();
        sendResponse(stamped);
        return;
      }
      if(msg?.type === 'CLEAR_PENDING_TRANSFER'){
        await chrome.storage.local.remove(['pendingTransfer','lastTransfer']);
        await notifyPanel();
        sendResponse({ok:true});
        return;
      }
      sendResponse({ok:false,error:'Unknown message.'});
    }catch(err){
      sendResponse({ok:false,error:err?.message||String(err)});
    }
  })();
  return true;
});
