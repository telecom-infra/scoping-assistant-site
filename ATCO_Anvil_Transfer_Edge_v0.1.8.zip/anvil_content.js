function normText(v){
  return String(v ?? '').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim().toLowerCase().replace(/:$/,'');
}
function visible(el){
  if(!el) return false;
  const r=el.getBoundingClientRect();
  return r.width>0 && r.height>0;
}
function labelForControl(el){
  return el?.closest('.flow-panel-gutter')?.querySelector('.label-text')?.textContent?.trim() || '';
}
function controlForLabel(target, preferred){
  const wanted=normText(target);
  const matches=[];
  for(const gutter of document.querySelectorAll('.flow-panel-gutter')){
    const label=gutter.querySelector('.label-text');
    if(!label || normText(label.textContent)!==wanted) continue;
    const controls=[...gutter.querySelectorAll('input, select, textarea')].filter(visible);
    if(preferred){
      const filtered=controls.filter(c => {
        if(preferred==='select') return c.tagName==='SELECT';
        if(preferred==='textarea') return c.tagName==='TEXTAREA';
        if(preferred==='input') return c.tagName==='INPUT';
        return true;
      });
      matches.push(...filtered);
    } else matches.push(...controls);
  }
  return matches;
}
function getControl(target, preferred){
  return controlForLabel(target, preferred)[0] || null;
}
function formReady(){
  return !!getControl('Project Number','input');
}
function nativeSet(el, value){
  el.focus();
  const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(proto,'value')?.set;
  if(setter) setter.call(el, value); else el.value=value;
  el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:String(value??'')}));
  el.dispatchEvent(new Event('change',{bubbles:true}));
  el.blur();
}
function normalizeOptionText(v){
  return String(v??'').trim().replace(/\s+/g,' ').replace(/\s*-\s*/g,'-').toLowerCase();
}
function selectByText(select, wanted){
  const target=normalizeOptionText(wanted);
  const options=[...select.options];
  let opt=options.find(o=>normalizeOptionText(o.text)===target);
  if(!opt){
    const code=(String(wanted).match(/\b\d{5}\b/)||[])[0];
    const clli=(String(wanted).match(/\b[A-Za-z]{4}\b/)||[])[0]?.toLowerCase();
    if(code) opt=options.find(o=>String(o.text).replace(/\s+/g,' ').includes(code));
    if(!opt && clli) opt=options.find(o=>String(o.text).toLowerCase().includes(clli));
  }
  if(!opt) return {ok:false,error:`Option not found: ${wanted}`};
  select.focus();
  select.value=opt.value;
  select.dispatchEvent(new Event('input',{bubbles:true}));
  select.dispatchEvent(new Event('change',{bubbles:true}));
  select.blur();
  return {ok:true,selected:opt.text};
}
function formatDate(v){
  if(!v) return '';
  const m=String(v).match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if(m) return `${Number(m[2])}/${Number(m[3])}/${m[1]}`;
  return String(v);
}
function setInput(label,value){
  const c=getControl(label,'input');
  if(!c) return {ok:false,error:`Field not found: ${label}`};
  nativeSet(c,String(value??''));
  return {ok:true,value:c.value};
}
function setSelect(label,value){
  const c=getControl(label,'select');
  if(!c) return {ok:false,error:`Dropdown not found: ${label}`};
  return selectByText(c,value);
}
function setTextarea(label,value){
  const c=getControl(label,'textarea');
  if(!c) return {ok:false,error:`Field not found: ${label}`};
  nativeSet(c,String(value??''));
  return {ok:true,value:c.value};
}

async function transfer(fields){
  if(!formReady()) return {ok:false,count:0,results:[],error:'The Anvil Create Project form was not detected.'};
  const results=[];
  const mappings=[
    ['projectNumber','Project Number','input',v=>setInput('Project Number',v)],
    ['altProjectNumber','Alternate Project Number','input',v=>setInput('Alternate Project Number',v)],
    ['projectAddress','Project Address/Description','input',v=>setInput('Project Address/Description',v)],
    ['dateReceived','Date Received','input',v=>setInput('Date Received',formatDate(v))],
    ['customer','Customer','select',v=>setSelect('Customer',v)],
    ['scope','Work Type','select',v=>setSelect('Work Type',v)],
    ['exchange','Exchange','select',v=>setSelect('Exchange',v)],
    ['assignedCoordinator','Assigned To','select',v=>setSelect('Assigned To',v)],
    ['scoperNotes','Notes','textarea',v=>setTextarea('Notes',v)]
  ];
  for(const [key,label,type,fn] of mappings){
    if(!(key in fields)) continue;
    const value=fields[key];
    if(String(value??'').trim()===''){
      results.push({key,label,ok:false,skipped:true,error:'Blank value'});
      continue;
    }
    const r=fn(value);
    results.push({key,label,type,...r});
    // Give Anvil's runtime a moment after each field, especially dropdowns.
    await new Promise(resolve=>setTimeout(resolve,70));
  }
  const failed=results.filter(r=>!r.ok && !r.skipped);
  const skipped=results.filter(r=>r.skipped);
  return {
    ok: failed.length===0,
    count: results.filter(r=>r.ok).length,
    failed: failed.length,
    skipped: skipped.length,
    results,
    warning: skipped.length ? `${skipped.length} selected field${skipped.length===1?' was':'s were'} blank and skipped.` : ''
  };
}

function status(){
  const ready=formReady();
  chrome.runtime.sendMessage({
    type:'ANVIL_STATUS',
    ready,
    detail:ready?'Anvil Create Project page detected.':'Open Anvil → Create Project.'
  }).catch(()=>{});
}
chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
  if(msg?.type==='ATCO_TRANSFER_TO_ANVIL'){
    transfer(msg.fields||{}).then(sendResponse);
    return true;
  }
});
status();
const observer=new MutationObserver(()=>status());
observer.observe(document.documentElement,{subtree:true,childList:true});
setInterval(status,2000);
